# Privacy Policy — SlotSync

**Last updated: April 2026**

## Overview

SlotSync is a Chrome extension that connects to Google Calendar to help you find available meeting times and schedule meetings with colleagues. This policy explains how the extension handles your data.

## Data Collected

SlotSync stores the following data **locally in your browser only**:

- Your Google OAuth access token (used to authenticate API requests, expires automatically)
- Your Zoom room URL and any additional Zoom room URLs you add
- Your Assistant Mode preference
- Free/busy calendar data retrieved during availability checks is used only to render the availability grid and is never stored

No calendar event content, email body text, or personal data beyond the above is stored.

## Google API Access

SlotSync requests access to the following Google APIs when you sign in:

- **Google Calendar** - to read free/busy data and create calendar events on your behalf
- **Google People / Directory** - to search for colleague names and email addresses for the autocomplete feature

This data is used only within the extension to provide its core functionality. It is never transmitted to any third-party server.

## Data Storage

All data is stored using Chrome's `storage.local` API. It never leaves your browser and is not accessible to any website or third party.

## Data Sharing

No data is collected, transmitted, or shared with any external server, service, or third party beyond the Google APIs listed above, which are accessed directly from your browser using your own OAuth credentials.

## Sign Out

You can sign out at any time using the Sign out button. This clears your stored token from local storage immediately.

## Permissions

- **identity** - used to handle the Google OAuth sign-in flow
- **storage** - used to save your settings and auth token locally
- **sidePanel** - used to display the extension in Chrome's side panel

## Changes to This Policy

This policy may be updated occasionally. The latest version will always be available at this URL.

## Contact

For questions about this extension, open an issue on the GitHub repository.
